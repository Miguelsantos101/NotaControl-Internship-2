﻿using escolaNc.Interfaces;
using escolaNc.Modelos;
using System.Collections.Generic;

namespace escolaNc.Servicos
{
    public class RelatoriosService : IRelatoriosService
    {
        public List<RelFaturamento> ServicosContratados()
        {
            throw new System.NotImplementedException();
        }
    }
}
